<?php $__env->startSection('title'); ?>
Home Page
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

  <div class="album py-5 bg-light">
    <div class="container">
      <div class="row">
        <?php $__currentLoopData = $hospitals; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $d): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="col-md-3">
          <div class="card mb-4 shadow-sm">
            <a href="<?php echo e(url('hospital/detail')); ?>/<?php echo e($d->id); ?>"><img class="card-img-top" src="<?php echo e(asset('storage')); ?>/<?php echo e($d->img); ?>" alt="<?php echo e($d->name); ?>" /></a>
            <div class="card-body">
              <p class="card-text"><?php echo e($d->name); ?></p>
              <div class="d-flex justify-content-between align-items-center">
                <div class="btn-group">
                  <a href="<?php echo e(url('hospital/detail')); ?>/<?php echo e($d->id); ?>" class="btn btn-sm btn-outline-secondary">View Detail</a>
                </div>
              </div>
            </div>
          </div>
        </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
      </div>
      <div class="row">
        <div class="col-sm-12">
          <?php echo e($hospitals->links('vendor.pagination.bootstrap-4')); ?>

        </div>
      </div>
    </div>
  </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.front', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>