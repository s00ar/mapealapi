<?php $__env->startSection('content'); ?>
<div class="d-flex justify-content-between flex-wrap flex-md-nowrap align-items-center pt-3"></div>
  <h2 class="mb-4">Hospitals</h2>
  <div class="table-responsive">
    <table class="table table-hover table-bordered">
      <thead>
        <tr>
          <th>#</th>
          <th>Image</th>
          <th>Name</th>
          <th>Address</th>
          <th>Speciality</th>
          <th>Contact</th>
          <th>Action</th>
        </tr>
      </thead>
      <tbody>
        <?php if(count($data)>0): ?>
        <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $d): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr>
          <td><?php echo e($d->id); ?></td>
          <td><img width="100" src="<?php echo e(asset('storage/')); ?>/<?php echo e($d->img); ?>" /></td>
          <td><?php echo e($d->name); ?></td>
          <td><?php echo e($d->address); ?></td>
          <td><?php echo e($d->speciality); ?></td>
          <td><?php echo e($d->contact); ?></td>
          <td>
            <a href="admin/hospital/edit/<?php echo e($d->id); ?>" class="btn btn-info btn-sm mb-1"><span data-feather="edit"></span></a>
            <a onclick="return confirm('Are you sure to delete this?')" href="admin/hospital/delete/<?php echo e($d->id); ?>" class="btn btn-danger btn-sm mb-1"><span data-feather="delete"></span></a>
          </td>
        </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <tr>
          <td colspan="6"><?php echo e($data->links()); ?></td>
        </tr>
        <?php endif; ?>
      </tbody>
    </table>
  </div>
  <?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.admin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>