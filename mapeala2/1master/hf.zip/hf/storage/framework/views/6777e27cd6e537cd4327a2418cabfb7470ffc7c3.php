<?php $__env->startSection('title','Register'); ?>
<?php $__env->startSection('content'); ?>
<h3 class="mt-4 mb-4">Register</h3>
<?php if($errors->any()): ?>
<div class="alert alert-danger">
    <ul>
        <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <li><?php echo e($error); ?></li>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </ul>
</div>
<?php endif; ?>
<?php if(Session::has('success')): ?>
<p class="alert alert-success"><?php echo e(session('success')); ?></p>
<?php endif; ?>
<table class="table-bordered table">
    <form action="<?php echo e(url('user/store')); ?>" method="post">
        <?php echo e(csrf_field()); ?>

        <tr>
            <th>Full Name</th>
            <td><input type="text" class="form-control" name="_name" /></td>
        </tr>
        <tr>
            <th>Email</th>
            <td><input type="email" class="form-control" name="_email" /></td>
        </tr>
        <tr>
            <th>Password</th>
            <td><input type="password" class="form-control" name="_password" /></td>
        </tr>
        <tr>
            <th>Category</th>
            <td>
                <select class="form-control" name="_category">
                    <option value="">--- Category ---</option>
                    <option value="1">Hardware</option>
                    <option value="2">Software</option>
                </select>
            </td>
        </tr>
        <tr>
            <td colspan="2">
                <input type="submit" value="Register" class="btn btn-danger" />
            </td>
        </tr>
    </form>
</table>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('layout.front', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>