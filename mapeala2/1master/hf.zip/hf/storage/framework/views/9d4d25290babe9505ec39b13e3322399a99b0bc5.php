<?php $__env->startSection('title'); ?>
Home Page
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
  <div class="album py-3 bg-light">
    <div class="container">
      <div class="row">
        <div class="col-sm-9">
            <h1 class="mb-4"><?php echo e($detail->name); ?></h1>
            <p><img height="350" class="card-img-top" src="<?php echo e(asset('storage')); ?>/<?php echo e($detail->img); ?>" alt="<?php echo e($detail->name); ?>"></p>
            <hr />
            <h4 class="mt-3">Speciality</h4>
            <p><?php echo e($detail->speciality); ?></p>
            <hr />
            <h4 class="mt-3">Contact Information</h4>
            <p><?php echo e($detail->contact); ?></p>
            <hr />
            <h4 class="mt-3">Address Information</h4>
            <p><?php echo e($detail->address); ?></p>
        </div>
      </div>
    </div>
  </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.front', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>