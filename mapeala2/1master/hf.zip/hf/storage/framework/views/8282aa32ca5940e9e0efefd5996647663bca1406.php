<?php $__env->startSection('title','Support System'); ?>
<?php $__env->startSection('content'); ?>
<h3 class="mt-4 mb-4">My Tickets</h3>
<div class="list-group">
    <a href="#" class="list-group-item list-group-item-action">
        Cras justo odio
        <span class="float-right">
            <span class="badge badge-warning">Answers 123</span>
        </span>
    </a>
    <a href="#" class="list-group-item list-group-item-action">
        Cras justo odio
        <span class="float-right">
            <span class="badge badge-warning">Answers 123</span>
        </span>
    </a>
    <a href="#" class="list-group-item list-group-item-action">
        Cras justo odio
        <span class="float-right">
            <span class="badge badge-warning">Answers 123</span>
        </span>
    </a>
</div>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('layout.front', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>